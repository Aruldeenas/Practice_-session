resource "aws_s3_bucket" "new_bucket" {
  bucket = "my-new-bucket-00980897788"
  

  tags = {
    Name = "my_s3"
  }
}